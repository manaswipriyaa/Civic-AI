"""
Thin wrapper around the Gemini API.

If GEMINI_API_KEY is not set, every function here returns a canned
mock response instead of calling out to Google, so the rest of the
app (and the frontend) works out of the box during development.
"""
import os
import json
import logging

logger = logging.getLogger("civicai.gemini")

API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
MOCK_MODE = not API_KEY

_model = None
if not MOCK_MODE:
    try:
        import google.generativeai as genai

        genai.configure(api_key=API_KEY)
        _model = genai.GenerativeModel("gemini-1.5-flash")
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("Failed to init Gemini client, falling back to mock mode: %s", exc)
        MOCK_MODE = True


def _mock_chat_reply(message: str) -> str:
    lower = message.lower()
    if "traffic" in lower:
        return (
            "[MOCK] Traffic on MG Road and Outer Ring Road is currently heavy due to "
            "ongoing metro construction. Expect 15-20 minute delays. Try the Inner "
            "Ring Road as an alternate route."
        )
    if "hospital" in lower:
        return (
            "[MOCK] The nearest government hospital is City General Hospital, "
            "2.3 km away, open 24/7. Emergency ward is on the ground floor."
        )
    if "scheme" in lower or "eligib" in lower:
        return (
            "[MOCK] Based on general eligibility criteria, you may qualify for the "
            "Urban Housing Subsidy and the Senior Citizen Healthcare Scheme. "
            "Upload a scheme document and ask me for specifics."
        )
    return (
        "[MOCK] This is a placeholder Gemini response — set GEMINI_API_KEY in "
        "backend/.env to get real answers. You asked: \"" + message.strip() + "\""
    )


def chat(message: str, history: list[dict] | None = None) -> str:
    """Send a chat message to Gemini, or return a mock reply."""
    if MOCK_MODE or _model is None:
        return _mock_chat_reply(message)

    try:
        convo = _model.start_chat(history=history or [])
        response = convo.send_message(message)
        return response.text
    except Exception as exc:
        logger.error("Gemini chat call failed: %s", exc)
        return "Sorry, I couldn't reach the AI service right now. Please try again."


def answer_from_context(question: str, context_chunks: list[str]) -> str:
    """RAG-style answer grounded in provided document chunks, or a mock reply."""
    if MOCK_MODE or _model is None:
        if not context_chunks:
            return "[MOCK] No relevant document content found for that question."
        snippet = context_chunks[0][:180]
        return (
            f"[MOCK] Based on the uploaded document, here's the relevant excerpt: "
            f"\"{snippet}...\" (set GEMINI_API_KEY for a real synthesized answer)"
        )

    context = "\n\n".join(context_chunks) or "No context available."
    prompt = (
        "Answer the question using ONLY the context below. If the answer isn't "
        "in the context, say so explicitly.\n\n"
        f"CONTEXT:\n{context}\n\nQUESTION: {question}"
    )
    try:
        response = _model.generate_content(prompt)
        return response.text
    except Exception as exc:
        logger.error("Gemini RAG call failed: %s", exc)
        return "Sorry, I couldn't process that document question right now."


def classify_complaint(text: str) -> dict:
    """Classify a citizen complaint into a department + priority, or mock it."""
    if MOCK_MODE or _model is None:
        lower = text.lower()
        if "garbage" in lower or "waste" in lower or "trash" in lower:
            dept, priority = "Waste Management", "High"
        elif "water" in lower or "leak" in lower or "pipe" in lower:
            dept, priority = "Water Supply", "High"
        elif "light" in lower or "electric" in lower:
            dept, priority = "Electricity Board", "Medium"
        elif "road" in lower or "pothole" in lower:
            dept, priority = "Roads & Infrastructure", "Medium"
        else:
            dept, priority = "General Administration", "Low"
        return {
            "department": dept,
            "priority": priority,
            "summary": f"[MOCK] Categorized: {text.strip()[:80]}",
        }

    prompt = (
        "Classify this citizen complaint. Respond ONLY with compact JSON in the "
        'exact shape {"department": string, "priority": "Low"|"Medium"|"High", '
        '"summary": string}. No markdown, no extra text.\n\n'
        f"COMPLAINT: {text}"
    )
    try:
        response = _model.generate_content(prompt)
        raw = response.text.strip().strip("`").removeprefix("json").strip()
        return json.loads(raw)
    except Exception as exc:
        logger.error("Gemini classification failed, falling back to mock: %s", exc)
        return {
            "department": "General Administration",
            "priority": "Low",
            "summary": text.strip()[:80],
        }
