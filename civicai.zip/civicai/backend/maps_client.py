"""
Real nearby-places search via the Google Places API (New).

If GOOGLE_MAPS_API_KEY is not set, falls back to the static mock list in
mock_data.py so the app still runs.

Note on traffic: Google's live traffic/road data (Roads API, Routes API
traffic-aware ETAs) requires a billed Google Cloud project and is a
separate, more involved integration than Places search. This client does
NOT attempt to fake that — the /api/traffic endpoint stays mock-only and
says so, rather than presenting static numbers as if they were live.
"""
import os
import logging
import requests

import mock_data

logger = logging.getLogger("civicai.maps")

API_KEY = os.getenv("GOOGLE_MAPS_API_KEY", "").strip()
MOCK_MODE = not API_KEY

_TYPE_MAP = {
    "hospital": "hospital",
    "police": "police",
    "fire": "fire_station",
    "school": "school",
    "bus_station": "bus_station",
}


def nearby_services(lat: float, lng: float, service_type: str | None, radius_m: int = 5000) -> list[dict]:
    if MOCK_MODE:
        items = mock_data.SERVICES
        if service_type:
            items = [s for s in items if s["type"] == service_type]
        return items

    types_to_search = [_TYPE_MAP[service_type]] if service_type in _TYPE_MAP else list(_TYPE_MAP.values())
    results = []
    for i, place_type in enumerate(types_to_search):
        try:
            resp = requests.post(
                "https://places.googleapis.com/v1/places:searchNearby",
                headers={
                    "Content-Type": "application/json",
                    "X-Goog-Api-Key": API_KEY,
                    "X-Goog-FieldMask": "places.displayName,places.formattedAddress,places.location,places.nationalPhoneNumber",
                },
                json={
                    "includedTypes": [place_type],
                    "maxResultCount": 5,
                    "locationRestriction": {
                        "circle": {"center": {"latitude": lat, "longitude": lng}, "radius": radius_m}
                    },
                },
                timeout=8,
            )
            resp.raise_for_status()
            places = resp.json().get("places", [])
            reverse_type = [k for k, v in _TYPE_MAP.items() if v == place_type][0]
            for j, p in enumerate(places):
                results.append(
                    {
                        "id": f"{reverse_type}-{j}",
                        "type": reverse_type,
                        "name": p.get("displayName", {}).get("text", "Unknown"),
                        "distance_km": None,  # Places API doesn't return distance directly; compute client-side if needed
                        "open_24h": None,
                        "phone": p.get("nationalPhoneNumber", "N/A"),
                        "address": p.get("formattedAddress"),
                    }
                )
        except Exception as exc:
            logger.error("Places API call failed for type %s: %s", place_type, exc)
    return results or mock_data.SERVICES
