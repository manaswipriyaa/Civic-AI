import os
import logging

from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session

load_dotenv()

import gemini_client
import rag_store
import mock_data
import maps_client
from db import init_db, get_db, User, Complaint, Document
from auth import hash_password, verify_password, create_token, get_current_user, get_current_user_optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("civicai")

app = FastAPI(title="CivicAI API", version="0.2.0")

origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "gemini_mock_mode": gemini_client.MOCK_MODE,
        "maps_mock_mode": maps_client.MOCK_MODE,
    }


# ---------- Auth ----------

class SignupRequest(BaseModel):
    name: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class AuthResponse(BaseModel):
    token: str
    name: str
    email: str


@app.post("/api/auth/signup", response_model=AuthResponse)
def signup(req: SignupRequest, db: Session = Depends(get_db)):
    if len(req.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    existing = db.query(User).filter(User.email == req.email).first()
    if existing:
        raise HTTPException(409, "An account with this email already exists")
    user = User(name=req.name, email=req.email, password_hash=hash_password(req.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return AuthResponse(token=create_token(user.id), name=user.name, email=user.email)


@app.post("/api/auth/login", response_model=AuthResponse)
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == req.email).first()
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return AuthResponse(token=create_token(user.id), name=user.name, email=user.email)


@app.get("/api/auth/me", response_model=AuthResponse)
def me(user: User = Depends(get_current_user)):
    return AuthResponse(token="", name=user.name, email=user.email)


# ---------- Chat ----------

class ChatRequest(BaseModel):
    message: str
    history: list[dict] | None = None


class ChatResponse(BaseModel):
    reply: str
    mock_mode: bool


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    if not req.message.strip():
        raise HTTPException(400, "message must not be empty")
    reply = gemini_client.chat(req.message, req.history)
    return ChatResponse(reply=reply, mock_mode=gemini_client.MOCK_MODE)


# ---------- Documents / RAG ----------

@app.post("/api/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: User | None = Depends(get_current_user_optional),
):
    raw = await file.read()
    try:
        text = raw.decode("utf-8", errors="ignore")
    except Exception:
        raise HTTPException(400, "Could not read file as text")

    doc_id = rag_store.add_document(file.filename, text)  # keeps in-memory retrieval index

    record = Document(user_id=user.id if user else None, filename=file.filename, content=text)
    db.add(record)
    db.commit()
    db.refresh(record)

    return {"id": doc_id, "db_id": record.id, "filename": file.filename}


@app.get("/api/documents")
def list_documents(db: Session = Depends(get_db)):
    rows = db.query(Document).order_by(Document.created_at.desc()).all()
    return [{"id": d.id, "filename": d.filename, "created_at": d.created_at.isoformat()} for d in rows]


class DocQuestionRequest(BaseModel):
    question: str


@app.post("/api/documents/query")
def query_documents(req: DocQuestionRequest):
    chunks = rag_store.retrieve(req.question)
    answer = gemini_client.answer_from_context(req.question, chunks)
    return {"answer": answer, "sources_used": len(chunks), "mock_mode": gemini_client.MOCK_MODE}


# ---------- Services finder ----------

@app.get("/api/services")
def get_services(type: str | None = None, lat: float | None = None, lng: float | None = None):
    if lat is not None and lng is not None:
        return maps_client.nearby_services(lat, lng, type)
    # No location provided — use mock data centered on a default city point
    items = mock_data.SERVICES
    if type:
        items = [s for s in items if s["type"] == type]
    return items


# ---------- Traffic ----------
# NOTE: kept mock-only on purpose. Real live traffic needs Google's billed
# Routes/Roads API (traffic-aware ETAs) — see maps_client.py docstring.

@app.get("/api/traffic")
def get_traffic():
    return mock_data.TRAFFIC


# ---------- Complaints ----------

class ComplaintRequest(BaseModel):
    text: str


@app.post("/api/complaints")
def create_complaint(
    req: ComplaintRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not req.text.strip():
        raise HTTPException(400, "text must not be empty")
    classification = gemini_client.classify_complaint(req.text)
    complaint = Complaint(
        user_id=user.id,
        text=req.text,
        department=classification["department"],
        priority=classification["priority"],
        summary=classification["summary"],
        status="Submitted",
    )
    db.add(complaint)
    db.commit()
    db.refresh(complaint)
    return _serialize_complaint(complaint)


@app.get("/api/complaints")
def list_complaints(
    db: Session = Depends(get_db),
    user: User | None = Depends(get_current_user_optional),
    mine: bool = False,
):
    query = db.query(Complaint)
    if mine:
        if user is None:
            raise HTTPException(401, "Log in to view your own complaints")
        query = query.filter(Complaint.user_id == user.id)
    rows = query.order_by(Complaint.created_at.desc()).all()
    return [_serialize_complaint(c) for c in rows]


def _serialize_complaint(c: Complaint) -> dict:
    return {
        "id": c.id,
        "text": c.text,
        "department": c.department,
        "priority": c.priority,
        "summary": c.summary,
        "status": c.status,
        "created_at": c.created_at.isoformat(),
    }


# ---------- Analytics ----------

@app.get("/api/analytics")
def get_analytics():
    return mock_data.ANALYTICS
