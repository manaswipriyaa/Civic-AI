SERVICES = [
    {"id": 1, "type": "hospital", "name": "City General Hospital", "distance_km": 2.3, "open_24h": True, "phone": "108"},
    {"id": 2, "type": "hospital", "name": "Sunrise Government Hospital", "distance_km": 4.1, "open_24h": True, "phone": "108"},
    {"id": 3, "type": "police", "name": "Sector 12 Police Station", "distance_km": 1.5, "open_24h": True, "phone": "100"},
    {"id": 4, "type": "fire", "name": "Central Fire Station", "distance_km": 3.0, "open_24h": True, "phone": "101"},
    {"id": 5, "type": "school", "name": "Municipal Higher Secondary School", "distance_km": 0.8, "open_24h": False, "phone": "N/A"},
    {"id": 6, "type": "bus_station", "name": "Central Bus Depot", "distance_km": 1.2, "open_24h": True, "phone": "N/A"},
]

TRAFFIC = [
    {"road": "MG Road", "status": "heavy", "delay_min": 18, "cause": "Metro construction"},
    {"road": "Outer Ring Road", "status": "heavy", "delay_min": 22, "cause": "Peak hour volume"},
    {"road": "Inner Ring Road", "status": "moderate", "delay_min": 8, "cause": "Normal flow"},
    {"road": "Lake View Road", "status": "clear", "delay_min": 0, "cause": None},
]

ANALYTICS = {
    "top_complaints": [
        {"category": "Waste Management", "count": 142},
        {"category": "Roads & Infrastructure", "count": 98},
        {"category": "Water Supply", "count": 76},
        {"category": "Electricity Board", "count": 41},
    ],
    "pollution_trend": [
        {"day": "Mon", "aqi": 118},
        {"day": "Tue", "aqi": 132},
        {"day": "Wed", "aqi": 121},
        {"day": "Thu", "aqi": 145},
        {"day": "Fri", "aqi": 139},
        {"day": "Sat", "aqi": 110},
        {"day": "Sun", "aqi": 98},
    ],
    "water_usage_ml_per_day": 42.7,
    "active_complaints": 61,
    "resolved_this_week": 34,
}

COMPLAINTS: list[dict] = []
