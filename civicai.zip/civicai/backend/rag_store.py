"""
Minimal in-memory document store for the RAG demo.

This intentionally avoids a real vector DB so the starter runs with zero
extra infra. Swap in a proper embedding index (e.g. Vertex AI Matching
Engine, pgvector, Chroma) for production use — the retrieve() function
is the only thing that needs to change.
"""
import re
import uuid

_DOCS: dict[str, dict] = {}


def _chunk(text: str, size: int = 500) -> list[str]:
    words = text.split()
    chunks, current = [], []
    length = 0
    for word in words:
        current.append(word)
        length += len(word) + 1
        if length >= size:
            chunks.append(" ".join(current))
            current, length = [], 0
    if current:
        chunks.append(" ".join(current))
    return chunks


def add_document(filename: str, text: str) -> str:
    doc_id = str(uuid.uuid4())[:8]
    _DOCS[doc_id] = {"filename": filename, "chunks": _chunk(text)}
    return doc_id


def list_documents() -> list[dict]:
    return [{"id": k, "filename": v["filename"], "chunk_count": len(v["chunks"])} for k, v in _DOCS.items()]


def retrieve(question: str, top_k: int = 3) -> list[str]:
    """Naive keyword-overlap retrieval. Good enough for a demo, not for prod."""
    q_words = set(re.findall(r"\w+", question.lower()))
    scored = []
    for doc in _DOCS.values():
        for chunk in doc["chunks"]:
            c_words = set(re.findall(r"\w+", chunk.lower()))
            overlap = len(q_words & c_words)
            if overlap:
                scored.append((overlap, chunk))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [chunk for _, chunk in scored[:top_k]]
