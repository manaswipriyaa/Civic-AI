import { useEffect, useState } from "react";
import { api } from "../lib/api";

const TYPES = [
  { key: "", label: "All" },
  { key: "hospital", label: "Hospitals" },
  { key: "police", label: "Police" },
  { key: "fire", label: "Fire" },
  { key: "school", label: "Schools" },
  { key: "bus_station", label: "Bus Stations" },
];

export default function Services() {
  const [type, setType] = useState("");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .services(type || undefined)
      .then(setItems)
      .finally(() => setLoading(false));
  }, [type]);

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <h1 className="font-display font-700 text-2xl mb-1">Find a Service</h1>
      <p className="text-slate text-sm mb-6">Nearby public services, sorted by distance.</p>

      <div className="flex gap-2 flex-wrap mb-6">
        {TYPES.map((t) => (
          <button
            key={t.key}
            onClick={() => setType(t.key)}
            className={`font-mono text-xs uppercase tracking-wide px-3 py-1.5 rounded-sm border transition-colors ${
              type === t.key ? "bg-ink text-paper border-ink" : "border-line text-slate hover:border-ink"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="text-slate font-mono text-sm">Loading…</p>
      ) : (
        <div className="border border-line rounded-sm divide-y divide-line bg-white">
          {items
            .slice()
            .sort((a, b) => a.distance_km - b.distance_km)
            .map((s) => (
              <div key={s.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-display font-600">{s.name}</p>
                  <p className="text-xs text-slate font-mono uppercase mt-0.5">
                    {s.type.replace("_", " ")} · {s.distance_km} km away
                    {s.open_24h ? " · Open 24h" : ""}
                  </p>
                </div>
                <span className="font-mono text-xs text-ink border border-line px-2 py-1 rounded-sm">
                  {s.phone}
                </span>
              </div>
            ))}
          {items.length === 0 && <p className="p-4 text-sm text-slate">No services found for this filter.</p>}
        </div>
      )}
    </div>
  );
}
