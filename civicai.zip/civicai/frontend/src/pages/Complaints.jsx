import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";
import { useAuth } from "../lib/AuthContext";

const PRIORITY_STYLE = {
  High: "bg-alert/10 text-alert border-alert/40",
  Medium: "bg-signal/10 text-signal border-signal/40",
  Low: "bg-success/10 text-success border-success/40",
};

export default function Complaints() {
  const { user } = useAuth();
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [complaints, setComplaints] = useState([]);
  const [showMine, setShowMine] = useState(false);
  const [error, setError] = useState("");

  function refresh(mine = showMine) {
    api.listComplaints(mine).then(setComplaints).catch(() => setComplaints([]));
  }

  useEffect(() => refresh(showMine), [showMine]);

  async function submit(e) {
    e.preventDefault();
    if (!text.trim()) return;
    setError("");
    setSubmitting(true);
    try {
      await api.createComplaint(text);
      setText("");
      refresh();
    } catch (err) {
      setError(err.message || "Couldn't submit — please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <h1 className="font-display font-700 text-2xl mb-1">Report an Issue</h1>
      <p className="text-slate text-sm mb-6">
        Describe the problem in your own words — CivicAI classifies it and routes it to the right department.
      </p>

      {!user ? (
        <div className="border border-line rounded-sm bg-white p-6 text-center mb-8">
          <p className="text-sm mb-3">Log in to report an issue and track its status.</p>
          <Link
            to="/login"
            className="inline-block bg-ink text-paper font-mono text-xs uppercase tracking-wider px-5 py-2.5 rounded-sm"
          >
            Log in
          </Link>
        </div>
      ) : (
        <form onSubmit={submit} className="flex gap-2 mb-4">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="e.g. Garbage hasn't been collected for 3 days"
            className="flex-1 border border-line rounded-sm px-4 py-3 text-sm bg-white focus:outline-none focus:border-signal"
          />
          <button
            type="submit"
            disabled={submitting}
            className="bg-ink text-paper font-mono text-xs uppercase tracking-wider px-5 rounded-sm disabled:opacity-50"
          >
            Submit
          </button>
        </form>
      )}
      {error && <p className="text-alert text-xs font-mono mb-4">{error}</p>}

      <div className="flex items-center justify-between mb-3">
        <h2 className="font-mono text-xs uppercase tracking-widest text-slate">
          {showMine ? "My reports" : "All reports"}
        </h2>
        {user && (
          <button
            onClick={() => setShowMine((v) => !v)}
            className="font-mono text-xs uppercase tracking-wide underline underline-offset-2 text-slate hover:text-ink"
          >
            {showMine ? "Show all" : "Show mine only"}
          </button>
        )}
      </div>

      <div className="space-y-3">
        {complaints.map((c) => (
          <div key={c.id} className="border border-line rounded-sm bg-white p-4">
            <div className="flex items-start justify-between gap-4">
              <p className="text-sm">{c.text}</p>
              <span
                className={`shrink-0 font-mono text-[10px] uppercase tracking-wide px-2 py-1 rounded-sm border ${PRIORITY_STYLE[c.priority] || ""}`}
              >
                {c.priority}
              </span>
            </div>
            <p className="text-xs text-slate font-mono mt-2 uppercase">
              → {c.department} · {c.status}
            </p>
          </div>
        ))}
        {complaints.length === 0 && <p className="text-sm text-slate">No reports yet.</p>}
      </div>
    </div>
  );
}
