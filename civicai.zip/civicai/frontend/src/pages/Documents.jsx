import { useEffect, useRef, useState } from "react";
import { api } from "../lib/api";

export default function Documents() {
  const [docs, setDocs] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState(null);
  const [asking, setAsking] = useState(false);
  const [error, setError] = useState("");
  const fileInput = useRef(null);

  function refresh() {
    api.listDocuments().then(setDocs).catch(() => {});
  }

  useEffect(refresh, []);

  async function handleUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setError("");
    setUploading(true);
    try {
      await api.uploadDocument(file);
      refresh();
    } catch (err) {
      setError("Upload failed — make sure the file is a plain text document.");
    } finally {
      setUploading(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  }

  async function ask(e) {
    e.preventDefault();
    if (!question.trim()) return;
    setAsking(true);
    setAnswer(null);
    setError("");
    try {
      const res = await api.queryDocuments(question);
      setAnswer(res);
    } catch (err) {
      setError("Couldn't get an answer right now.");
    } finally {
      setAsking(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <h1 className="font-display font-700 text-2xl mb-1">Document Q&A</h1>
      <p className="text-slate text-sm mb-6">
        Upload a city document — a scheme brochure, policy, or advisory — and ask questions
        answered directly from its contents.
      </p>

      <div className="border border-dashed border-line rounded-sm bg-white p-6 mb-6 text-center">
        <input
          ref={fileInput}
          type="file"
          accept=".txt,.md,.csv,text/plain"
          onChange={handleUpload}
          className="hidden"
          id="doc-upload"
        />
        <label
          htmlFor="doc-upload"
          className="font-mono text-xs uppercase tracking-wider bg-ink text-paper px-4 py-2.5 rounded-sm cursor-pointer inline-block hover:bg-ink/90"
        >
          {uploading ? "Uploading…" : "Choose a text file to upload"}
        </label>
        <p className="text-xs text-slate mt-2">Plain text files only in this demo (.txt, .md, .csv)</p>
      </div>

      {docs.length > 0 && (
        <div className="mb-8">
          <h2 className="font-mono text-xs uppercase tracking-widest text-slate mb-2">Uploaded documents</h2>
          <div className="border border-line rounded-sm bg-white divide-y divide-line">
            {docs.map((d) => (
              <div key={d.id} className="px-4 py-2.5 text-sm flex justify-between">
                <span>{d.filename}</span>
                <span className="text-slate text-xs font-mono">{new Date(d.created_at).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <form onSubmit={ask} className="flex gap-2 mb-4">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="e.g. What documents are needed for a birth certificate?"
          className="flex-1 border border-line rounded-sm px-4 py-3 text-sm bg-white focus:outline-none focus:border-signal"
        />
        <button
          type="submit"
          disabled={asking}
          className="bg-ink text-paper font-mono text-xs uppercase tracking-wider px-5 rounded-sm disabled:opacity-50"
        >
          Ask
        </button>
      </form>

      {error && <p className="text-alert text-xs font-mono mb-4">{error}</p>}

      {answer && (
        <div className="border border-line rounded-sm bg-white p-4">
          <p className="text-sm">{answer.answer}</p>
          <p className="text-xs text-slate font-mono mt-3 uppercase">
            {answer.sources_used} source chunk{answer.sources_used === 1 ? "" : "s"} used
            {answer.mock_mode ? " · mock mode" : ""}
          </p>
        </div>
      )}
    </div>
  );
}
