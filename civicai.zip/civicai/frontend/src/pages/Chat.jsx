import { useState, useRef, useEffect } from "react";
import { api } from "../lib/api";

const SUGGESTIONS = [
  "Why is traffic heavy today?",
  "Where is the nearest hospital?",
  "What government schemes can I apply for?",
];

export default function Chat() {
  const [messages, setMessages] = useState([
    { role: "assistant", text: "Hi, I'm CivicAI. Ask me anything about traffic, services, or city schemes." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [mockMode, setMockMode] = useState(null);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send(text) {
    const message = (text ?? input).trim();
    if (!message || loading) return;
    setMessages((m) => [...m, { role: "user", text: message }]);
    setInput("");
    setLoading(true);
    try {
      const res = await api.chat(message);
      setMockMode(res.mock_mode);
      setMessages((m) => [...m, { role: "assistant", text: res.reply }]);
    } catch (err) {
      setMessages((m) => [
        ...m,
        { role: "assistant", text: "Couldn't reach the backend. Is it running on port 8000?" },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-10 flex flex-col h-[calc(100vh-64px-49px)]">
      <div className="flex items-center justify-between mb-4">
        <h1 className="font-display font-700 text-2xl">Ask CivicAI</h1>
        {mockMode && (
          <span className="font-mono text-[10px] uppercase tracking-wider text-alert border border-alert/40 px-1.5 py-0.5 rounded-sm">
            Mock mode — set GEMINI_API_KEY for live answers
          </span>
        )}
      </div>

      <div className="flex-1 overflow-y-auto border border-line rounded-sm bg-white p-4 space-y-3">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] px-4 py-2.5 text-sm rounded-sm ${
                m.role === "user" ? "bg-ink text-paper" : "bg-paper text-ink border border-line"
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-paper border border-line px-4 py-2.5 text-sm rounded-sm text-slate font-mono">
              CivicAI is typing…
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div className="flex gap-2 mt-3 flex-wrap">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => send(s)}
            className="font-mono text-xs uppercase tracking-wide border border-line px-3 py-1.5 rounded-sm text-slate hover:border-signal hover:text-ink transition-colors"
          >
            {s}
          </button>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
        className="flex gap-2 mt-3"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about traffic, hospitals, schemes…"
          className="flex-1 border border-line rounded-sm px-4 py-3 text-sm bg-white focus:outline-none focus:border-signal"
        />
        <button
          type="submit"
          disabled={loading}
          className="bg-ink text-paper font-mono text-xs uppercase tracking-wider px-5 rounded-sm disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
}
