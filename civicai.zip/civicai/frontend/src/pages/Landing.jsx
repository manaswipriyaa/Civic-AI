import { Link } from "react-router-dom";
import CityTicker from "../components/CityTicker";

const FEATURES = [
  { to: "/chat", title: "Ask CivicAI", desc: "Plain-language answers about traffic, services, and schemes.", tag: "GEMINI" },
  { to: "/documents", title: "Document Q&A", desc: "Upload a scheme or policy document and ask questions about it.", tag: "RAG" },
  { to: "/services", title: "Find a Service", desc: "Locate the nearest hospital, police station, or school.", tag: "MAP DATA" },
  { to: "/traffic", title: "Traffic Status", desc: "Live congestion, delays, and recommended routes.", tag: "LIVE" },
  { to: "/complaints", title: "Report an Issue", desc: "Describe a problem — CivicAI routes it to the right department.", tag: "AI ROUTED" },
  { to: "/analytics", title: "City Data", desc: "Complaint trends, pollution levels, and resource usage.", tag: "DASHBOARD" },
];

export default function Landing() {
  return (
    <div>
      <section className="max-w-6xl mx-auto px-6 pt-16 pb-12">
        <p className="font-mono text-xs uppercase tracking-widest text-signal mb-4">
          Municipal Decision Intelligence Platform
        </p>
        <h1 className="font-display font-800 text-4xl md:text-6xl leading-[1.05] tracking-tight max-w-3xl">
          One assistant for every citizen and city service.
        </h1>
        <p className="mt-6 text-slate max-w-xl text-lg">
          Traffic, hospitals, government schemes, and civic complaints — answered
          in plain language, grounded in real city documents.
        </p>
        <div className="mt-8 flex gap-3">
          <Link
            to="/chat"
            className="bg-ink text-paper font-mono text-sm uppercase tracking-wider px-5 py-3 rounded-sm hover:bg-ink/90 transition-colors"
          >
            Ask a question →
          </Link>
          <Link
            to="/complaints"
            className="border border-ink font-mono text-sm uppercase tracking-wider px-5 py-3 rounded-sm hover:bg-ink hover:text-paper transition-colors"
          >
            Report an issue
          </Link>
        </div>
      </section>

      <CityTicker />

      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="flex items-baseline justify-between mb-8">
          <h2 className="font-display font-700 text-2xl">What CivicAI does</h2>
          <span className="font-mono text-xs text-slate uppercase">5 services · demo build</span>
        </div>
        <div className="grid md:grid-cols-2 gap-px bg-line border border-line">
          {FEATURES.map((f) => (
            <Link
              key={f.to}
              to={f.to}
              className="bg-paper hover:bg-white transition-colors p-6 flex flex-col justify-between min-h-[150px] group"
            >
              <div className="flex items-start justify-between">
                <h3 className="font-display font-700 text-lg">{f.title}</h3>
                <span className="font-mono text-[10px] uppercase tracking-wider text-signal border border-signal/40 px-1.5 py-0.5 rounded-sm">
                  {f.tag}
                </span>
              </div>
              <p className="text-sm text-slate mt-3">{f.desc}</p>
              <span className="font-mono text-xs mt-4 text-ink group-hover:text-signal transition-colors">
                Open →
              </span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
