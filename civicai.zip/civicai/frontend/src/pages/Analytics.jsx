import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid } from "recharts";
import { api } from "../lib/api";

export default function Analytics() {
  const [data, setData] = useState(null);

  useEffect(() => {
    api.analytics().then(setData);
  }, []);

  if (!data) return <div className="max-w-5xl mx-auto px-6 py-10 text-slate font-mono text-sm">Loading…</div>;

  return (
    <div className="max-w-5xl mx-auto px-6 py-10">
      <h1 className="font-display font-700 text-2xl mb-1">City Data</h1>
      <p className="text-slate text-sm mb-8">Complaint trends, pollution levels, and resource usage.</p>

      <div className="grid sm:grid-cols-3 gap-px bg-line border border-line mb-8">
        <Stat label="Active Complaints" value={data.active_complaints} />
        <Stat label="Resolved This Week" value={data.resolved_this_week} />
        <Stat label="Water Usage (ML/day)" value={data.water_usage_ml_per_day} />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="border border-line rounded-sm bg-white p-4">
          <h2 className="font-mono text-xs uppercase tracking-widest text-slate mb-4">Top Complaint Categories</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={data.top_complaints} layout="vertical" margin={{ left: 16 }}>
              <XAxis type="number" hide />
              <YAxis dataKey="category" type="category" width={140} tick={{ fontSize: 11, fontFamily: "IBM Plex Mono" }} />
              <Tooltip />
              <Bar dataKey="count" fill="#14213D" radius={[0, 2, 2, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="border border-line rounded-sm bg-white p-4">
          <h2 className="font-mono text-xs uppercase tracking-widest text-slate mb-4">Pollution Trend (AQI)</h2>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data.pollution_trend}>
              <CartesianGrid stroke="#D6D9D1" strokeDasharray="3 3" />
              <XAxis dataKey="day" tick={{ fontSize: 11, fontFamily: "IBM Plex Mono" }} />
              <YAxis tick={{ fontSize: 11, fontFamily: "IBM Plex Mono" }} />
              <Tooltip />
              <Line type="monotone" dataKey="aqi" stroke="#F2A93B" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="bg-paper p-5">
      <p className="font-mono text-[10px] uppercase tracking-widest text-slate mb-1">{label}</p>
      <p className="font-display font-800 text-3xl">{value}</p>
    </div>
  );
}
