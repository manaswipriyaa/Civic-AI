import { useEffect, useState } from "react";
import { api } from "../lib/api";

const STATUS_STYLE = {
  heavy: "bg-alert/10 text-alert border-alert/40",
  moderate: "bg-signal/10 text-signal border-signal/40",
  clear: "bg-success/10 text-success border-success/40",
};

export default function Traffic() {
  const [roads, setRoads] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.traffic().then(setRoads).finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-6 py-10">
      <h1 className="font-display font-700 text-2xl mb-1">Traffic Status</h1>
      <p className="text-slate text-sm mb-6">Current congestion across major roads.</p>

      {loading ? (
        <p className="text-slate font-mono text-sm">Loading…</p>
      ) : (
        <div className="space-y-3">
          {roads.map((r) => (
            <div key={r.road} className="border border-line rounded-sm bg-white p-4 flex items-center justify-between">
              <div>
                <p className="font-display font-600">{r.road}</p>
                {r.cause && <p className="text-xs text-slate mt-0.5">{r.cause}</p>}
              </div>
              <div className="text-right">
                <span
                  className={`font-mono text-xs uppercase tracking-wide px-2 py-1 rounded-sm border ${STATUS_STYLE[r.status]}`}
                >
                  {r.status}
                </span>
                {r.delay_min > 0 && (
                  <p className="text-xs text-slate font-mono mt-1">+{r.delay_min} min</p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
