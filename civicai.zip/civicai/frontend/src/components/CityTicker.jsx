const ITEMS = [
  "TRAFFIC: MG ROAD — HEAVY (+18 MIN)",
  "AQI TODAY: 118 — MODERATE",
  "ACTIVE COMPLAINTS: 61",
  "RESOLVED THIS WEEK: 34",
  "NEAREST HOSPITAL: CITY GENERAL — 2.3 KM",
  "WATER USAGE: 42.7 ML/DAY",
];

export default function CityTicker() {
  const loop = [...ITEMS, ...ITEMS];
  return (
    <div className="bg-ink text-signal border-y border-signal/30 overflow-hidden">
      <div className="ticker-track flex gap-10 py-2 whitespace-nowrap font-mono text-xs uppercase tracking-wider w-max">
        {loop.map((item, i) => (
          <span key={i} className="flex items-center gap-10">
            {item}
            <span className="text-paper/30">◆</span>
          </span>
        ))}
      </div>
    </div>
  );
}
