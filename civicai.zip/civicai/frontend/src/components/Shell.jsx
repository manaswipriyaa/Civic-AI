import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/AuthContext";

const LINKS = [
  { to: "/", label: "Home", end: true },
  { to: "/chat", label: "Ask CivicAI" },
  { to: "/documents", label: "Documents" },
  { to: "/services", label: "Find a Service" },
  { to: "/traffic", label: "Traffic" },
  { to: "/complaints", label: "Report an Issue" },
  { to: "/analytics", label: "City Data" },
];

export default function Shell() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-line bg-ink text-paper sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <NavLink to="/" className="font-display font-800 text-lg tracking-tight uppercase shrink-0">
            Civic<span className="text-signal">AI</span>
          </NavLink>
          <nav className="hidden lg:flex gap-1 font-mono text-xs uppercase tracking-wider">
            {LINKS.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.end}
                className={({ isActive }) =>
                  `px-3 py-2 rounded-sm transition-colors whitespace-nowrap ${
                    isActive ? "bg-signal text-ink" : "text-paper/80 hover:bg-white/10"
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </nav>
          <div className="shrink-0 font-mono text-xs uppercase tracking-wider">
            {user ? (
              <button
                onClick={() => {
                  logout();
                  navigate("/");
                }}
                className="px-3 py-2 rounded-sm text-paper/80 hover:bg-white/10"
              >
                {user.name} · Log out
              </button>
            ) : (
              <NavLink
                to="/login"
                className={({ isActive }) =>
                  `px-3 py-2 rounded-sm ${isActive ? "bg-signal text-ink" : "text-paper/80 hover:bg-white/10"}`
                }
              >
                Log in
              </NavLink>
            )}
          </div>
        </div>
      </header>

      <nav className="lg:hidden flex overflow-x-auto gap-1 bg-ink text-paper px-4 py-2 font-mono text-xs uppercase tracking-wider">
        {LINKS.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            end={l.end}
            className={({ isActive }) =>
              `px-3 py-1.5 whitespace-nowrap rounded-sm ${
                isActive ? "bg-signal text-ink" : "text-paper/80"
              }`
            }
          >
            {l.label}
          </NavLink>
        ))}
      </nav>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="border-t border-line py-6 text-center text-xs text-slate font-mono">
        CIVICAI — MUNICIPAL DECISION INTELLIGENCE — DEMO BUILD
      </footer>
    </div>
  );
}
